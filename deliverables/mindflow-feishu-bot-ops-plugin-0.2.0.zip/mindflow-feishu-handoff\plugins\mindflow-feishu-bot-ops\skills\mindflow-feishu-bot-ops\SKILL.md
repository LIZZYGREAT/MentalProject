---
name: mindflow-feishu-bot-ops
description: Inspect, preflight, deploy, accept, and roll back the MindFlow Feishu forecast-care bot and its user-bound project Skill tools. Use when reviewing a MindFlow source handoff, checking event lifecycle and implicit obligation extraction, post-event outcome cards, forward-only reforecasting, deterministic proactive care, OAuth/worker/DeepSeek boundaries, validating production settings without exposing secrets, or preparing a go/no-go report.
---

# MindFlow Feishu Bot Operations

Treat this Skill as an operations and review procedure. Do not treat it as an application runtime component or grant it authority to contact users, change Feishu permissions, or enable external-LLM processing without explicit approval.

## Select the workflow

1. For source review, read `references/architecture.md`, `references/runtime-skill-contract.md`, and `references/review-checklist.md`.
2. For deployment, read `references/deployment-runbook.md` and run `scripts/mindflow_preflight.py` before changing server state.
3. For end-to-end verification, read `references/acceptance.md` and record evidence for every applicable case.
4. For handoff completion, produce a report with the reviewed source identity, environment, checks performed, findings by severity, rollback readiness, and a clear go/no-go decision.

## Preserve safety boundaries

- Use DeepSeek as the conversational intent and tool-selection layer only after consent. Bind every project tool to the trusted Feishu user; never expose `user_id` as a model argument.
- Route natural language through the reviewed DeepSeek tool-calling loop and route card buttons directly to the same allowlisted toolbox. Never create a second authorization path for buttons.
- Keep project code and deterministic rules authoritative for calculations, records, permissions, alerts, intervention timing, and side effects. Validate tool arguments and model replies before use or delivery.
- Keep the separate calendar event-semantic extractor bounded to normalization and rule-friendly features. Reject prose, unknown fields, out-of-range values, and schema-invalid output.
- Verify that prospective forecasts freeze `forecast_as_of`, default to the completion scenario without claiming a confirmed outcome, and preserve all pre-feedback points when an outcome creates a forward update.
- Verify that completion cards are offered only for completion-relevant work/deliverable events. Courses, meetings, exams, sleep, meals, exercise, and recovery should default to `not_applicable` unless an explicit reviewed policy says otherwise.
- Keep proactive timing deterministic and user-controlled. Enforce opt-in, quiet hours, daily budget, durable episode deduplication, prediction freshness, and uncertainty wording.
- Never print or commit `.env`, Feishu secrets, DeepSeek keys, OAuth tokens, session secrets, database contents, or real calendar event text.
- Start production with `CARE_AGENT_ENABLED=false` and `SEMANTIC_API_ENABLED=false`. Deterministic event lifecycle, outcome cards, and proactive policy must continue to work with both disabled. Enable the conversational Agent only after its DeepSeek tool loop, consent gate, output safety review, and fallback pass acceptance; enable event semantics separately.
- Do not use `docker compose down -v`; preserve the `app_data` volume during upgrades and rollback.
- Stop and request authorization before publishing Feishu app changes, opening firewall ports, modifying DNS/TLS, or enabling real-user external processing.

## Review before deployment

Confirm the snapshot contains no secrets, generated data, token files, or personal event content. Verify the three-process boundary: Web app, Feishu WebSocket gateway, and durable care worker. Trace the intended conversation path `message -> trusted binding -> consent -> DeepSeek -> allowlisted Skill tool -> validated result -> safety review -> reply`, and the button path `card action -> trusted binding -> allowlisted Skill tool -> safety review -> reply`. Inspect authentication, replay/idempotency, retries, private-chat restriction, card validation, OAuth isolation, logs, and fallbacks.

Run the repository's existing tests and frontend build. Treat any failing check, consent bypass, cross-user access, secret exposure, duplicate outbound message, or irreversible migration as a release blocker.

## Run preflight

From the unpacked project root, run:

```text
python <plugin>/skills/mindflow-feishu-bot-ops/scripts/mindflow_preflight.py --project-root . --env-file .env --run-tests --run-build --run-compose-check
```

The script reports names and states only; it never prints secret values. Resolve every `ERROR`. Review each `WARN` and document acceptance or remediation. Do not mistake preflight success for live Feishu acceptance.

For the final target architecture, add `--require-deepseek-agent` only after the runtime tool-calling loop exists. An error on the current snapshot correctly records that the target is not yet deployment-complete.

## Deploy and accept

Follow `references/deployment-runbook.md` in order. Back up persistent data first, validate the effective Compose configuration, build, start, check health, and inspect redacted logs. Then execute `references/acceptance.md` using a dedicated test tenant/account and synthetic calendar titles.

If a live check fails, disable the affected feature first. Roll back the application image/source while retaining the data volume. Restore data only when a migration or data corruption requires it and the restore target has been verified.

## Report results

Return a compact report containing:

- source archive name, checksum or commit, reviewer, date, and target environment;
- unit/build/Compose/preflight results;
- Feishu permissions, events, OAuth redirect, and WebSocket status;
- DeepSeek endpoint/model label, tool-calling loop, natural-language and button cases, fallback result, and consent status;
- P0/P1/P2 findings with file evidence and remediation;
- backup location, rollback command/version, and final `GO`, `CONDITIONAL GO`, or `NO-GO`.

Never mark `GO` while a P0 remains open.
