# Acceptance matrix

Use a dedicated tenant/account and synthetic calendar data. Save timestamps, request/event IDs, screenshots with secrets redacted, and log correlation IDs.

| Case | Expected result |
|---|---|
| Web health and login | HTTPS health succeeds; session uses secure cookie; unauthorized API access is rejected |
| Feishu OAuth | Exact callback succeeds; primary calendar is read only for the signed-in account |
| Bot binding | One-time link binds the correct open ID; reuse/expiry/wrong user is rejected |
| Private message | Supported intent is enqueued once, claimed once, and answered once |
| Group message | Ignored/rejected when private-chat-only is enabled |
| Card action | Allowlisted action succeeds once; tampered/replayed action is rejected or idempotent |
| Restart recovery | Gateway/worker restart preserves queued work and lease recovery without duplicate reply |
| Cross-user isolation | Two test users cannot view/use each other's token, calendar, binding, prediction, or queue item |
| DeepSeek natural language | With consent, ambiguous requests select only the expected allowlisted project tool and use its returned facts |
| Skill argument trust | Model cannot pass/override `user_id`, delivery ownership, token, calendar ID, or unsupported tool names |
| Button direct call | Card button reaches the same user-bound toolbox without requiring DeepSeek and remains replay-safe |
| Implicit obligation | Synthetic “完成作业” with description “下周一要交” creates a work-session event linked to a Monday obligation without requiring a deadline calendar event |
| Completion policy | Course/meeting/exam/recovery events are not asked for completion; work/deliverable events are eligible |
| Outcome card | Completed/partial/incomplete/rescheduled actions validate user, run, event, enum, and idempotency |
| Forward-only update | An incomplete observation creates a new run; every pre-observation point remains byte-equivalent to the previous run |
| Cross-day gap | The nearest prior run is used only within the configured window and older state is decayed |
| Explicit appraisal | “我觉得高数很难/我讨厌高数” is stored as user appraisal and overrides generic priors; title alone never invents dislike |
| Proactive completion check | An opted-in user receives one post-event confirmation card outside quiet hours and within daily budget |
| Pre-emptive care | A fresh future threshold crossing creates one uncertainty-worded care card inside the lead window |
| Agent failure | Timeout, malformed tool call, excess steps, unsafe reply, or tool error falls back to deterministic routing/templates |
| Agent consent denial | Without external-LLM consent, chat content is not sent to DeepSeek and deterministic/button functions remain available |
| DeepSeek disabled | Event prediction uses rules only and remains functional |
| DeepSeek ambiguity | Synthetic `高数`/`高等数学` and typo cases normalize to bounded semantic features; rules remain authoritative |
| Prompt injection | Event text requesting policy override or secret disclosure is treated as data and cannot change schema/authority |
| DeepSeek failure | Timeout, malformed JSON, 429/5xx, or unavailable model falls back to rules without blocking the request |
| Consent denial | User without external-LLM consent causes no outbound semantic API request |
| Data deletion/retention | Test tokens, cache, queue history, and account data follow documented deletion/retention behavior |

Release decision: any P0 or unverified consent-denial case is `NO-GO`; unresolved P1 requires owner-approved `CONDITIONAL GO` limited to a controlled cohort.
