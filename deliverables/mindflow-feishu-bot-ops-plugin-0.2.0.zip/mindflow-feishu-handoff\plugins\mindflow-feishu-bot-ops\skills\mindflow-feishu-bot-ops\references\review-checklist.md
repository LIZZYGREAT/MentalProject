# Source and security review checklist

## Release blockers (P0)

- Cross-user token, calendar, binding, prediction, or care-event access.
- External LLM call without effective per-user consent at the call site.
- Secrets or OAuth tokens in archive, repository, logs, exceptions, API payloads, or screenshots.
- Unverified sender/card identity, replayable action causing duplicate side effects, or public/group chat processing contrary to policy.
- Model-supplied identity, non-allowlisted tool access, unvalidated tool arguments/results, or model output directly controlling diagnosis, risk classification, stress score, alert, intervention, or side effects.
- Database loss risk, destructive volume operation, or rollback without a verified backup.

## Authentication and identity

- Confirm session cookies are secure behind HTTPS and the production secret is stable and strong.
- Trace Web user ID, Feishu open ID, binding token, OAuth token, and calendar access end to end.
- Confirm binding tokens are one-time, expiring, scoped, and never logged.
- Confirm each user receives a distinct token record/path and cannot choose another user's calendar ID.

## Bot intake and delivery

- Verify only configured message and card event types are accepted.
- Verify private-chat-only behavior, event deduplication, durable enqueue before acknowledgement, lease expiry, retry cap, and poison-event behavior.
- Verify action IDs and values are allowlisted and validated; escaped user text must not become executable instructions.
- Verify outbound delivery records idempotency and retry state without duplicating messages.
- Verify completion buttons validate run ownership, event membership, completion policy, outcome enum, and repeated actions.

## Forecast causality and proactive care

- Verify normalized prediction inputs persist stable event IDs, event kind, completion policy, lifecycle version, implicit obligation provenance, and `forecast_as_of`.
- Verify an ordinary course receives `completion_policy=none`; a work block with “下周一要交” links to an obligation even without a separate deadline event.
- Verify pending/default completion creates no unfinished carry; explicit partial/incomplete/rescheduled feedback affects only points from `observed_at` onward and may carry into later days.
- Verify a missing previous-day run falls back only within the bounded carry window and applies state persistence decay.
- Verify proactive delivery requires explicit opt-in and enforces quiet hours, daily budget, episode deduplication, lead window, threshold, private binding, and uncertainty wording.
- Verify an external semantic request is impossible when the bound user's `allow_external_llm` is false.

## DeepSeek conversation Agent and Skill tools

- Confirm the runtime actually converts the project Skill into a controlled prompt and explicit JSON tool schemas; a `SKILL.md` file alone is not runtime integration.
- Confirm DeepSeek can select only the `CareToolbox.allowed_tools` set and cannot provide or override trusted `user_id`.
- Enforce a bounded tool-call loop, schema validation, argument size/range limits, timeout/retry budget, result filtering, prompt-injection isolation, and final reply safety review.
- Confirm card buttons map directly to the same toolbox and authorization checks, without trusting hidden card values for identity or ownership.
- Test ambiguous natural language, missing arguments, multiple requested actions, unsupported actions, tool errors, model timeout/malformed calls, and fallback to the deterministic router/templates.
- Confirm model conversation logging is minimal, redacted, access-controlled, retained for a defined period, and excluded when consent is absent.

## DeepSeek calendar semantics

- Verify minimal-data prompts, strict JSON schema, allowlisted keys, length/range clamps, timeouts, token cap, and no chain-of-thought persistence.
- Verify prompt/model/provider/version hashes are auditable without storing secrets.
- Test typo, abbreviation, negation, adversarial instructions, malformed JSON, timeout, 429, 5xx, and unavailable model.
- Confirm all failures produce deterministic rules-only behavior.
- Confirm cache keys do not mix users or incompatible prompt/model versions and define retention/deletion behavior.

## Operations

- Verify `.env` is absent from the handoff archive and `.env.example` contains placeholders only.
- Verify logs omit event titles/descriptions unless explicitly redacted and approved.
- Verify health/readiness, restart policies, disk capacity, clock/timezone, backup, restore drill, and log retention.
- Verify SQLite single-host assumptions and prevent multiple workers from violating lease/idempotency invariants.

## Severity

- P0: privacy, security, safety, cross-user isolation, irreversible loss, or duplicate external side effects. No-go.
- P1: high-probability functional/operational failure without immediate safety impact. Fix before broad release.
- P2: maintainability, observability, or low-impact edge case. Track with owner and date.
