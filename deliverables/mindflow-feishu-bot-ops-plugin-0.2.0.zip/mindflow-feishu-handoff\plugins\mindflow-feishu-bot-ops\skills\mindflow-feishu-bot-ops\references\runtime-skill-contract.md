# DeepSeek runtime Skill contract

## Meaning of Skill in production

The project Skill is a controlled capability contract, not a file that DeepSeek executes. Build an adapter that loads reviewed behavior instructions, exposes explicit JSON tool schemas to the DeepSeek-compatible chat API, validates returned tool calls, invokes `CareToolbox`, filters results, and asks the model for a final reply. Limit the loop to a small fixed number of tool steps and fall back to `DeterministicCareRouter` plus approved templates on any failure.

The trusted Feishu binding creates `CareToolbox(care_service, trusted_user_id)`. Never include `user_id` in a tool schema. Do not let the model access the database, filesystem, Feishu token, calendar ID, raw audit rows, or arbitrary internal APIs.

## Allowlisted tools

| Tool | Model-visible arguments | Purpose |
|---|---|---|
| `care_get_today_context` | optional `local_date` | Read the bound user's permitted current-day summary |
| `care_record_checkin` | validated `payload`; optional fixed source | Record explicit user observations |
| `care_run_today_assessment` | optional `local_date` | Run the existing deterministic assessment |
| `care_get_event_confirmations` | optional `local_date`, `as_of` | List ended completion-relevant events owned by the bound user |
| `care_record_event_outcome` | run ID, event ID, allowlisted outcome, optional observed time | Record a verified outcome and request a forward-only update |
| `care_record_event_appraisal` | topic plus bounded explicit appraisal fields | Persist the user's stated difficulty/dislike/control for matching future events |
| `care_get_support` | optional bounded `context` | Obtain a project-generated support suggestion |
| `care_submit_review` | `delivery_id`, bounded review payload | Record feedback after ownership verification |
| `care_update_preferences` | allowlisted preference changes | Apply explicit user choices, including consent/reminder settings |
| `calendar_connection_status` | none | Return a minimal connection state, never credentials/IDs |

Generate JSON Schema from reviewed definitions, not Python signatures alone. Set `additionalProperties: false`, length/range/enum limits, and required fields. Reject tool calls containing identity, token, calendar identifiers, SQL, file paths, URLs, prompt text, or unknown fields.

## Natural-language path

1. Validate event type, private chat, sender, binding, active account, deduplication, and high-risk fixed-response path.
2. Read the user's external-model consent locally. If denied, use deterministic routing and do not call DeepSeek.
3. Send only the minimum current message and reviewed Skill instructions. Do not attach raw calendar/history by default.
4. Validate DeepSeek tool name and arguments, execute through the bound toolbox, and filter the result.
5. Permit only a bounded second model turn to form a reply. Apply safety and privacy review before delivery.
6. Audit tool name, schema/prompt/model versions, latency, outcome, and redacted error—not raw secrets or unnecessary personal text.

## Temporal causality contract

Keep `forecast_as_of`, planned work remaining, completion policy, and observed outcome separate. Before an event ends, the primary forecast may assume completion but must not store a confirmed outcome. After explicit partial/incomplete/rescheduled feedback, create a new immutable run and freeze every point earlier than `observed_at`. Never use `assumed_completed` as a confirmed training label.

Parse an implicit obligation from the work-session description when supported by text, for example “今晚完成作业；下周一要交.” A separate calendar deadline event is optional. Preserve the evidence text only in the trusted prediction snapshot; expose only the minimal obligation name/due time to cards and tools.

## Button path

Map reviewed action names directly to the same toolbox, as the current router does. Treat card values as untrusted. Re-resolve the sender binding, validate action schema and delivery ownership, and enforce idempotency. Do not invoke DeepSeek merely to execute an unambiguous button; an optional model-written reply is unnecessary and adds failure/privacy surface.

## Required fallback

On missing consent, timeout, 429/5xx, unavailable model, malformed/unknown tool call, excessive steps, unsafe output, or tool failure, stop the model loop. Use deterministic routing/templates when safe, otherwise return a short retry/limitation message. Never replay a side-effecting tool automatically unless idempotency is proven.
