# Target architecture and current implementation boundary

## Confirmed target

MindFlow is a Feishu enterprise self-built app with an enabled bot. DeepSeek is the bot's conversational model. Project capabilities are exposed as user-bound Skill tools so DeepSeek can select them during conversation; Feishu card buttons can call the same tools directly.

```text
Natural language -> Feishu event -> identity/consent -> DeepSeek Agent -> tool call -> CareToolbox -> project service -> safety review -> reply
Card button      -> Feishu event -> identity/action check -> CareToolbox -> project service -> safety review -> reply
```

`SKILL.md` is policy/instruction material, not an executable API by itself. The runtime must provide DeepSeek with a controlled system prompt plus JSON tool schemas, execute allowlisted calls, return filtered tool results, and continue until a final reply or bounded step limit. Buttons bypass model intent selection but never bypass authorization, validation, audit, or safety.

## Runtime processes

| Process | Entry | Responsibility |
|---|---|---|
| Web app | `entry.app:app` | Login, onboarding, Feishu OAuth, APIs, built frontend, health endpoint |
| Bot gateway | `python -m entry.feishu_bot` | Feishu long connection, message/card event intake, durable inbox enqueue |
| Care worker | `python -m entry.care_worker` | Claim queued events, deterministic routing/tools, response delivery, retry/heartbeat |

All three share SQLite through the Compose `app_data` volume. This is a single-host deployment design; do not assume horizontal SQLite safety.

## Implemented paths

- Per-user Web login, profile/onboarding, Feishu OAuth token path, and Feishu identity binding.
- Feishu WebSocket reception, private-chat restriction, durable inbox, leases, retries, and card actions.
- Deterministic care intent routing, user-bound `CareToolbox`, and button-to-tool routing; the general DeepSeek conversation Agent is disabled and its runtime tool-calling loop is not yet implemented.
- DeepSeek-compatible event-semantic extraction, schema/range validation, cache, rule fusion, and rules-only fallback.
- Forecast-safe event normalization with stable event IDs, implicit obligation extraction from descriptions such as “下周一要交,” completion policy, explicit outcome observations, and immutable forward-update runs.
- User-bound completion/appraisal tools, direct Feishu outcome cards, and deterministic proactive polling with quiet hours, daily budget, and durable episode deduplication.
- Docker Compose services, application health check, tests, and frontend production build.

## Deliberately incomplete or deployment-dependent

- DeepSeek conversational Agent orchestration (prompt loading, JSON tool schemas, tool-call loop, result filtering, step limits, output review, consent and fallback) remains incomplete. Proactive scheduling is deterministic; it does not depend on the conversation Agent.
- Production RAG, multi-host queue/database scaling, KMS-backed token storage, and automated database migrations are not established.
- Feishu app publication, permission approval, public HTTPS, DNS, TLS, and real tenant acceptance require the deployment owner.
- A configured model label does not prove that the target DeepSeek account supports it. Verify the account endpoint/model with synthetic content.

## DeepSeek authority boundary

DeepSeek may understand conversational intent, choose an allowlisted project tool, organize a short reply, and separately normalize ambiguous calendar text such as `高数`. It must not supply identity, access storage directly, invent tool results, or directly decide a diagnosis, user risk, stress score, alert, intervention, or side effect. Project services and explicit user appraisal remain authoritative. Unsafe/invalid model output falls back to deterministic routing and approved templates.

## Important review focus

The source currently exposes global Agent/semantic API switches. Before a chat or real calendar text can leave the server, verify that each user's `allow_external_llm` consent is enforced at the actual call sites. Without that gate, keep both switches false and treat enabling them for real users as P0. Because the target requires a DeepSeek conversation Agent but the snapshot still uses `DeterministicCareRouter`, deployment is limited to deterministic beta behavior until the missing loop passes review.
