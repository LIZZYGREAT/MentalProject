# Deployment and rollback runbook

## Preconditions

Obtain explicit authorization for the server, domain/TLS, firewall, and Feishu application. Use Docker Engine with Compose v2, a public HTTPS origin, a dedicated test account, and sufficient persistent disk. Do not place secrets in shell history, chat, issue trackers, or the source archive.

## Prepare Feishu

Use an enterprise self-built app. Enable bot capability and long-connection event delivery. Publish the message receive and card action events required by the source, send-as-bot permission, and OAuth scopes listed in `.env.example`. Register the exact public HTTPS `/callback` URL. Keep tenant/app publication evidence in the deployment report.

## Configure

Copy `.env.example` to `.env` on the server and set values locally. At minimum set a random `FLASK_SECRET_KEY`, Feishu app credentials, exact HTTPS redirect/frontend/bind origins, bot enablement, worker enablement, secure cookies, and proxy behavior appropriate to one trusted reverse proxy.

Start with:

```text
SEMANTIC_API_ENABLED=false
CARE_AGENT_ENABLED=false
```

Do not reuse the Feishu app secret as another key. Remove bootstrap admin credentials after the first successful account creation. Restrict `.env`, token storage, database, and backups to the service account.

## Preflight and backup

Run the Skill preflight with tests, build, and Compose validation. Resolve errors. Record the source checksum/commit and image identifier. Back up the named volume or stop writers briefly and copy the SQLite database plus token directory consistently. Verify the backup exists and is readable before upgrading.

## Start

Build and start the Compose project, then check all three services. Confirm `/api/health` succeeds through both localhost and the public TLS endpoint. Inspect logs for startup/retry errors while redacting credentials, tokens, personal text, and cookies.

## Connect and accept

Complete Web login, onboarding, Feishu OAuth, and bot-account binding with a test account. Execute deterministic-path acceptance first. The reviewed snapshot does not yet implement the DeepSeek conversational tool-calling loop; do not label the target architecture complete or enable `CARE_AGENT_ENABLED` until that loop has been added and reviewed.

After per-user external-LLM consent is confirmed in code and behavior, the owner may add the DeepSeek key and enable the conversation Agent for a controlled synthetic chat test. Verify natural language selects an allowlisted project Skill tool, button actions reach the same tool with no model dependency, and model/tool failures fall back safely. Enable calendar semantic extraction separately after its own test.

Validate the exact model name available to the deployment account; treat the `.env.example` model label as configuration, not proof of availability. Keep thinking mode disabled unless the response parser, latency, cost, and privacy implications are separately reviewed.

## Roll back

If acceptance fails, disable the affected feature (`FEISHU_BOT_ENABLED` or `SEMANTIC_API_ENABLED`) and restart only the required services. For an application rollback, deploy the previously recorded source/image while retaining `app_data`. Never use `docker compose down -v`.

Restore the backup only if data migration or corruption requires it. Stop all writers, verify the target volume/path, retain the failed database for investigation, restore atomically, start one service at a time, and repeat health plus isolation tests.
