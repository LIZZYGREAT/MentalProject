"""Project-wide settings helpers."""

