# 飞书日历连接实现检查与 Device Flow 替代方案评审

> 评审日期：2026-08-02  
> 评审范围：当前 Mental_project 的飞书日历连接、`yet-another-lark-mcp-main/` 的认证与日历实现，以及用设备流替代 HTTP OAuth 回调的可行性。  
> 本文不包含 App Secret、access token、refresh token、calendar_id 或 open_id 等敏感值。

## 1. 结论先行

当前飞书日历连接的主链路在代码与自动化测试层面是完整的，前后端也能正常构建：

- 当前实现使用标准 OAuth 2.0 Authorization Code 流程。
- 授权记录按本项目登录用户隔离，不再复用全局 Token。
- 回调会校验 `state`，授权码不能再通过手工接口提交。
- Token 即将过期时会自动刷新，并对飞书一次性轮换的 refresh token 做线程与进程级串行保护。
- 日历连接检测会真实调用当前用户的主日历接口；预测流程会读取该用户自己的日程。
- 飞书相关后端测试与认证测试合计 **31 项通过**，Vue 前端生产构建通过。

`yet-another-lark-mcp-main/` 值得借鉴，但不能原样替换当前实现。它真正避免 HTTP 回调的方式是 **OAuth Device Flow（设备授权流）+ 服务端轮询 Token 端点**；WebSocket 长连接只用于飞书消息与卡片事件，不负责日历 OAuth 完成通知。

最终建议：

1. **生产 Web 应用暂时保留现有回调模式，并补 PKCE、加密 Token 存储、断开连接能力等安全增强。** 对稳定域名的 Web 应用，这是更直接、成熟的路径。
2. **如果核心目标是彻底取消公网 `/callback` 和飞书后台重定向 URL 配置，可以增加 Device Flow 作为第二种授权方式。** 先做灰度开关与真实应用验证，通过后再决定是否将其设为默认。
3. **不要把参考项目的单例 Token、全局主日历缓存、最长 10 分钟阻塞轮询和 WebSocket 代码直接搬入当前多用户 Flask 服务。** 这些实现依赖“单 App、单 owner、单进程 MCP”的前提，与本项目账号模型不同。

因此，对问题“能否借鉴它而不是继续通过回调函数实现”的准确回答是：**可以有条件地用设备流替代 OAuth HTTP 回调，但需要按当前项目的多用户架构重新实现；不能通过简单引用该 MCP 项目或改成 WebSocket 来完成替换。**

## 2. 当前实现确认

### 2.1 当前授权链路

现有链路如下：

```text
当前项目用户登录
  -> GET /api/feishu/get_url
  -> 服务端生成随机 state，并把 state 与项目 user_id 写入 Session
  -> 前端弹窗打开飞书授权页
  -> 飞书重定向 GET /callback?code=...&state=...
  -> 服务端校验 state 与授权所属项目用户
  -> POST /open-apis/authen/v2/oauth/token 换取用户 Token
  -> 保存到 data/user_tokens/user_<项目用户ID>.json
  -> 前端收到 postMessage 或检测到弹窗关闭
  -> GET /api/feishu/verify
  -> 使用 user_access_token 读取该用户主日历
```

关键代码位置：

- `entry/app.py:341`：按项目用户生成独立 Token 文件路径。
- `entry/app.py:745`：生成授权地址、保存随机 `state` 与当前项目用户 ID。
- `entry/app.py:783`：OAuth 回调，校验 `state` 后换取并保存 Token。
- `entry/app.py:840`：旧的手工授权码提交接口已禁用，返回 HTTP 410。
- `entry/app.py:1964`：返回连接状态，必要时自动刷新 Token。
- `entry/app.py:1989`：读取当前用户主日历，执行连接验证。
- `utils/get_token.py:239`：生成授权 URL，默认请求 `offline_access` 与日历只读权限。
- `utils/get_token.py:277`：用授权码调用 v2 Token 接口。
- `utils/get_token.py:338`：刷新 user_access_token 和 refresh token。
- `utils/get_token.py:555`：双重锁保护一次性 refresh token 的轮换与落盘。
- `utils/get_calendar_id.py:77`：读取当前 Token 对应的主日历。
- `utils/calendar_tool.py:145`：分页读取指定时间范围内的日程。
- `frontend/src/views/HomeView.vue:494`：打开授权弹窗并监听完成状态。
- `frontend/src/views/HomeView.vue:530`：触发连接检测。

### 2.2 当前功能具备的正确性与安全性

已经确认的优点：

- **用户隔离正确**：Web 请求总是把当前项目用户自己的 access token 注入日历拉取流程；存在注入 Token 时不会误用历史全局 `FEISHU_CALENDAR_ID`。
- **OAuth 请求归属正确**：随机 `state` 与当前项目用户 ID 一起保存在 Session，回调时使用常量时间比较，避免授权码被绑定给错误账号。
- **Token 生命周期处理较完整**：记录访问令牌与刷新令牌到期时间；访问令牌提前 5 分钟视为过期；刷新后保存新 refresh token。
- **并发刷新保护优于参考项目**：同时使用进程内锁和文件锁，避免多个 Web worker 同时消费同一个一次性 refresh token。
- **前端不会拿到 Token**：状态接口只返回是否有效、到期时间、scope 等元数据。
- **连接检测有实际业务含义**：不是只看本地文件，而是读取当前 Token 对应的主日历。
- **失败可降级**：预测流程读取飞书失败时回退到本地沙盒事件池，不让整次预测直接失败。

### 2.3 本次验证结果与边界

执行结果：

| 检查项 | 结果 |
|---|---|
| `tests/test_feishu_tokens.py` + `tests/test_auth.py` | 31 passed |
| Vue/Vite 生产构建 | 通过，34 个模块完成构建 |
| 本地用户 Token 文件 | 存在 1 份按用户隔离的 Token，包含 access token 与 refresh token |
| 本地 access token | 检查时已经过期，过期时间为 2026-08-01 15:09:33 UTC |
| 本地 refresh token | 检查时仍有效，记录的过期时间为 2026-08-08 13:09:33 UTC |

本次没有主动调用线上刷新接口，因为飞书 refresh token 为一次性轮换凭证；只为写评审而消费并重写真实凭证没有必要。因此本文确认的是 **代码链路、测试、构建和本地凭证可刷新状态**，不是一次完整的线上端到端日历读取证明。用户在界面点击“检测连接”时，系统会按现有逻辑先刷新过期 access token，再读取主日历，这才是线上最终确认动作。

### 2.4 当前仍值得改进的点

这些问题不影响“链路已实现”的结论，但建议在下一轮完善：

1. **Token 文件仍是明文 JSON。** `chmod(0600)` 在类 Unix 环境有帮助，但 Windows 下不能等价保证访问控制。生产环境应改为数据库字段加密、系统密钥环或专用密钥管理服务。
2. **缺少 PKCE。** 现有 `state` 可防 CSRF，但飞书当前授权码文档还支持并推荐 `S256` PKCE。可增加 `code_verifier`/`code_challenge`，并将 verifier 与当前授权会话绑定。
3. **缺少“断开飞书日历”操作。** 应允许用户删除本地 Token；如果开放平台提供撤销授权接口，也应同步撤销远端授权。
4. **回调页使用 `postMessage(..., "*")`。** 消息里没有 Token，风险有限，但仍应收紧为当前前端的准确 origin。
5. **日志包含日历标识信息。** `utils/get_calendar_id.py` 会记录解析后的 calendar_id/open_id；生产日志应掩码或删除。
6. **文件存储不适合横向扩容。** 多实例部署时，即使有文件锁，也要求共享文件系统；迁移到数据库后更容易支持事务、加密、审计与多实例。

## 3. `yet-another-lark-mcp-main/` 实际采用了什么方式

### 3.1 它没有取消 OAuth，只是改用了 Device Flow

参考项目的用户日历仍然依赖 user_access_token。认证流程如下：

```text
调用日历 MCP 工具
  -> withModuleAuth("calendar") 检查 Token 与日历 scope
  -> POST /oauth/v1/device_authorization 获取 device_code 和验证地址
  -> 向 owner 发送飞书授权卡片，或直接返回验证地址
  -> 用户在飞书/浏览器中确认授权
  -> MCP 服务每隔数秒轮询 /open-apis/authen/v2/oauth/token
  -> 获得 user_access_token 与 refresh token
  -> 保存 Token
  -> 原日历工具继续执行
```

关键代码位置：

- `yet-another-lark-mcp-main/src/auth.ts:393`：启动 Device Flow。
- `yet-another-lark-mcp-main/src/auth.ts:421`：最长轮询 10 分钟，等待飞书返回 Token。
- `yet-another-lark-mcp-main/src/auth-guard.ts:43`：日历等模块缺权限时按需触发授权。
- `yet-another-lark-mcp-main/src/tools/auth.ts:49`：提供 `feishu_auth_init` MCP 工具。
- `yet-another-lark-mcp-main/src/tools/calendar.ts`：用 SDK 和 user_access_token 操作主日历。
- `yet-another-lark-mcp-main/src/ws.ts`：WebSocket 接收消息和卡片点击事件。

### 3.2 WebSocket 长连接与日历授权不是一回事

参考项目宣传的“无需 webhook”针对的是飞书消息、卡片 callback 与 watch loop。它的 OAuth 完成状态仍由 `pollDeviceToken()` 定时轮询 Token 端点获得。

因此：

- WebSocket 可以避免为 **消息事件** 暴露公网 webhook。
- Device Flow 可以避免为 **OAuth 授权码** 暴露公网 redirect/callback。
- WebSocket 本身不能替代 user_access_token，也不能让应用直接读取任意用户的私人主日历。

如果改成只使用 tenant_access_token，调用身份会变成应用/机器人。它能访问的是应用身份可见的日历资源，不等价于当前产品“每个登录用户连接并读取自己的主日历”。

### 3.3 参考项目值得借鉴的部分

可以借鉴：

- **Device Flow**：不需要本项目暴露 OAuth HTTP 回调，适合本地开发、桌面应用、CLI、没有稳定公网域名的部署。
- **按模块最小权限申请**：日历、任务、文档分别维护 scope，不必一次申请全部权限。
- **按需授权**：调用受保护功能时才提示授权，降低初次使用门槛。
- **Token 静态加密思路**：参考实现用 App Secret 派生 AES-256-GCM 密钥，比明文 Token 文件更好；当前项目可以借鉴思想，但建议用独立主密钥或 KMS，不要直接把 App Secret 同时当加密根密钥。
- **主日历 ID 缓存和 SDK 封装**：可借鉴 API 封装、循环日程实例化与紧凑输出，但缓存必须按用户分区。
- **授权结果卡片/状态反馈**：可转化为当前 Vue 页面内的二维码、验证码、倒计时和完成状态。

### 3.4 不能原样照搬的部分

参考项目 README 已明确定位为单人使用。以下实现不适合当前多用户 Web 服务：

| 参考实现 | 在当前项目中的问题 |
|---|---|
| 每个 App ID 只有一个 TokenStore/owner | 多个项目用户会共享或覆盖同一飞书身份，破坏账号隔离 |
| `primaryCalId` 是进程级单例缓存 | 用户 A 的主日历 ID 可能被用户 B 复用 |
| Device Flow 最长阻塞 10 分钟 | 会长期占用 Flask worker/请求，重启后流程丢失，也不利于扩容 |
| `pendingDeviceCode`、授权提示状态为全局变量 | 并发用户或并发授权会互相覆盖 |
| refresh timer 为单进程定时器 | 多 worker 下可能同时刷新一次性 refresh token；当前项目已有的双重锁更可靠 |
| 刷新请求使用 form-urlencoded | 飞书 2026 版 v2 刷新文档规定 `application/json; charset=utf-8`，不应照抄 |
| 刷新只检查 `res.error` | 飞书错误也可能通过非零 `code` 返回，存在把失败响应当成功 Token 保存的风险 |
| `saveGrantedScopes(required)` 保存“请求的 scope” | 应以 Token 响应实际返回的 `scope` 为准，服务端可能裁剪授权范围 |
| WebSocket 卡片链路 | 当前需求仅连接日历时没有必要引入长连接、MCP server 和 watch loop |

另外，参考项目依赖目录当前没有安装自己的 `node_modules`，也没有现成测试脚本；本次对它的结论来自源码与文档审查，不等同于已经在本机 App 上跑通 Device Flow。

## 4. 两种授权方式对比

| 维度 | 当前 Authorization Code + Callback | 参考 Device Flow + Polling |
|---|---|---|
| 是否需要 user OAuth | 需要 | 需要 |
| 是否需要本项目 HTTP 回调 | 需要 | 不需要 |
| 是否需要公网可达 URL | 生产通常需要 | 本项目不需要，但用户仍需打开飞书验证地址 |
| 完成通知 | 飞书重定向携带一次性 code | 服务端轮询 Token 端点 |
| Web 产品体验 | 点击后弹窗授权，完成即回站 | 展示二维码/验证链接，页面轮询状态 |
| 服务端资源 | 一次回调请求 | 授权期间持续或分段轮询 |
| 多用户关联 | 现有 state + Session 已实现 | 必须另建 user_id + flow_id + device_code 状态模型 |
| 跨实例部署 | Session/Token 存储需共享 | pending flow、轮询任务、Token 均需共享存储 |
| 典型场景 | 有稳定后端域名的 Web 应用 | CLI、桌面、本地服务、无公网回调环境 |
| 当前项目改造量 | 较小，主要是安全增强 | 中等，需要新增后端状态机、前端交互与并发控制 |

## 5. 如果决定采用 Device Flow，建议这样落地

### 5.1 不要在一个 HTTP 请求里阻塞 10 分钟

建议拆成异步状态机：

```text
POST /api/feishu/device-auth/start
  -> 生成 flow_id
  -> 向飞书申请 device_code
  -> 服务端保存 pending flow（归属当前项目 user_id）
  -> 返回 verification_url、user_code、expires_at、建议轮询间隔

GET /api/feishu/device-auth/status/<flow_id>
  -> 验证 flow_id 属于当前项目用户
  -> 返回 pending / authorized / denied / expired / failed

后台任务或受控短轮询
  -> 按飞书返回 interval 查询 Token
  -> 处理 authorization_pending / slow_down / access_denied / expired
  -> 成功后原子保存该项目用户的 Token
```

前端只需展示验证链接/二维码、验证码、剩余时间，并每 2～5 秒查询本项目状态接口。不要把 `device_code` 或 App Secret 返回给浏览器。

### 5.2 多用户数据模型

至少保存：

- `flow_id`：高熵随机值，只作为本项目查询句柄。
- `app_user_id`：当前 Mental_project 用户 ID。
- `device_code_ciphertext`：加密保存，不写日志。
- `requested_scopes`：本次申请的权限。
- `status`：pending、authorized、denied、expired、failed、cancelled。
- `interval_seconds`、`next_poll_at`、`expires_at`。
- 成功后的 `access_token_ciphertext`、`refresh_token_ciphertext`、实际 `granted_scopes` 和各自到期时间。

数据库唯一约束应保证同一用户同一飞书 App 只有一个活动授权流程；Token 刷新继续复用现有的串行锁/原子更新思想。

### 5.3 建议的迁移顺序

1. 抽象统一的 `FeishuAuthorizationService`，让回调流与设备流共用 Token 规范化、加密存储、刷新和连接检测。
2. 先增加 Device Flow 功能开关，不删除 `/callback`。
3. 在一套测试飞书应用中开启并发布 User OAuth Device Flow，验证设备授权端点、scope、拒绝、超时、`slow_down` 和刷新轮换。
4. 增加多用户并发测试、进程重启恢复测试和两 worker 刷新竞争测试。
5. 灰度给内部用户；统计完成率、平均授权时长、失败码和刷新成功率。
6. 设备流稳定后，再决定默认方式。保留回调作为一段时间的兼容回退，最后才下线。

### 5.4 建议测试清单

- 用户 A/B 同时启动 Device Flow，不能互相读取状态或覆盖 Token。
- 同一用户重复点击连接，只保留一个活动 flow，旧 flow 被取消或明确失效。
- `authorization_pending` 不算失败；`slow_down` 必须增加轮询间隔。
- 拒绝、过期、网络超时和服务重启都能进入可恢复状态。
- Token 响应缺 access token 或 refresh token 时不能标记成功。
- 保存飞书实际返回的 scope，而不是默认相信请求 scope。
- 两个 worker 同时遇到过期 access token 时，只允许一次 refresh token 轮换。
- Device Flow 关闭或应用未发布相应配置时，前端给出明确指引并可回退到回调流。

## 6. 推荐决策

### 场景 A：部署有稳定公网 HTTPS 域名

继续使用当前回调流更合适。建议优先完成：

1. PKCE S256；
2. Token 加密与数据库化；
3. 精确 `postMessage` origin；
4. 日志脱敏；
5. 断开连接/重新授权；
6. 线上端到端连接监测。

### 场景 B：部署环境无法提供稳定公网回调，或希望同一套逻辑兼容桌面/本地运行

引入 Device Flow 是合理选择。采用上面的异步多用户设计，并复用当前 Token 刷新、按用户隔离和连接验证代码。此时可以在稳定后移除 `/callback` 与 `FEISHU_REDIRECT_URI`。

### 本项目当前推荐

**短期：保留回调，先增强安全。中期：新增 Device Flow 灰度能力。不要立即用参考目录整套替换。**

原因不是 Device Flow 不可行，而是参考实现解决的是“单人 MCP 在本地运行”的问题；当前项目解决的是“多个站内账号分别连接自己的飞书日历”。两者最值得复用的是授权协议与交互思路，而不是状态存储和运行模型。

## 7. 参考资料

本地源码：

- `utils/get_token.py`
- `utils/get_calendar_id.py`
- `utils/calendar_tool.py`
- `data_pipeline/fetcher.py`
- `entry/app.py`
- `frontend/src/views/HomeView.vue`
- `tests/test_feishu_tokens.py`
- `tests/test_auth.py`
- `yet-another-lark-mcp-main/src/auth.ts`
- `yet-another-lark-mcp-main/src/auth-guard.ts`
- `yet-another-lark-mcp-main/src/tools/auth.ts`
- `yet-another-lark-mcp-main/src/tools/calendar.ts`
- `yet-another-lark-mcp-main/src/ws.ts`
- `yet-another-lark-mcp-main/README.zh.md`
- `yet-another-lark-mcp-main/SETUP.md`
- `yet-another-lark-mcp-main/DESIGN-AUTH.md`

飞书官方资料（检查日期 2026-08-02）：

- [获取授权码](https://open.feishu.cn/document/authentication-management/access-token/obtain-oauth-code?lang=zh-CN)：说明 Web 授权码流程、redirect URI、state、PKCE 与 scope。
- [获取 user_access_token](https://open.feishu.cn/document/authentication-management/access-token/get-user-access-token?lang=zh-CN)：说明 v2 Token 接口、JSON 请求体、实际返回 scope 与 refresh token。
- [刷新 user_access_token](https://open.feishu.cn/document/uAjLw4CM/ukTMukTMukTM/authentication-management/access-token/refresh-user-access-token)：说明 refresh token 一次性轮换、JSON 请求与错误码。
- [查询日历列表](https://open.feishu.cn/document/server-docs/calendar-v4/calendar/list-2?lang=zh-CN)：说明 Token 类型决定当前调用身份。
- [Node SDK 一键创建应用](https://open.feishu.cn/document/mcp_open_tools/integrating-agents-with-feishu/scan-to-create-an-app-in-one-click-nodejs)：飞书官方已在 CLI/应用创建场景使用 RFC 8628 Device Authorization Grant。该页面能证明飞书生态支持设备授权协议，但不能替代对当前 User OAuth Device Flow 开关与端点的真实应用验证。

## 8. 一句话总结

当前飞书日历连接实现可用且测试完整；`yet-another-lark-mcp-main` 的 Device Flow 可以帮助取消 OAuth HTTP 回调，但必须改造成按项目用户隔离、异步轮询、可恢复且并发安全的 Web 版实现，不能直接搬用它的单人 MCP 架构。
