# 飞书机器人关怀服务改造需求规格

> 文档版本：v1.0-draft  
> 编写日期：2026-08-02  
> 适用项目：Mental_project  
> 关联文档：`info/feishu_calendar_integration_review_2026-08-02.md`  
> 文档用途：作为产品确认、技术设计、任务拆分、测试验收和后续迭代的统一需求基线。

## 1. 文档结论

项目将从“以 Web 页面为唯一入口、飞书仅作为日历数据源”改造为“双入口、同后端”的多用户关怀系统：

```text
Mental_project Web 页面 ─┐
                         ├─> 统一的用户、画像、预测、关怀和反馈服务
飞书自建应用机器人 ──────┘
```

飞书机器人作为新的日常交互入口，负责：

- 接收用户私聊消息；
- 引导绑定 Mental_project 账号；
- 接收轻量状态打卡；
- 查询并返回当日压力与活力摘要；
- 在用户授权后结合个人飞书日历运行预测；
- 根据用户偏好提供非临床、低打扰的关怀建议；
- 收集关怀是否有帮助等反馈；
- 后续支持经过明确同意的主动关怀消息。

当前 Flask/SQLite/Vue 项目继续作为业务核心。`yet-another-lark-mcp-main/` 只作为飞书 API、Device Flow、消息卡片和 Skill 组织方式的参考，不直接作为共享多用户生产服务。

## 2. 背景与当前基础

当前项目已经具备以下可复用能力：

- 多用户账号、Session、API Key 和管理员权限；
- 按 `user_id` 隔离的用户画像、问卷、日常上下文、预测运行与反馈；
- 飞书 OAuth、自动刷新、主日历查询和日程读取；
- 压力、活力及相关状态的日内预测；
- 基于持续时间、负荷累积、冷却时间和每日预算的关怀提示策略；
- `care_preferences`，包括开关、安静时段、每日消息数量、语气和支持方式；
- `momentary_state`、`care_review`、`prediction_review` 等反馈类型；
- 非临床定位和工程验证测试。

当前缺少：

- 飞书机器人消息接收和发送网关；
- 飞书 `open_id` 与项目 `user_id` 的可信绑定；
- 持久化消息队列和事件幂等；
- 可同时被 Web 和机器人调用的领域服务；
- 关怀 Tool 层；
- 关怀 Agent/Skill 运行器；
- 主动关怀的持久化投递、去重、重试和审计；
- 飞书卡片交互与反馈闭环；
- 针对机器人场景的隐私和安全边界。

## 3. 建设目标

### 3.1 产品目标

1. 用户可以在飞书私聊机器人完成日常关怀交互，而不必每次打开 Web 页面。
2. 机器人使用当前项目已有的用户画像、日程和预测结果，避免建立第二套关怀模型。
3. 用户可以在飞书中完成轻量状态记录、查询状态、获取建议和反馈。
4. 用户数据、飞书 Token、预测结果和关怀消息必须按项目用户隔离。
5. 主动关怀必须经过用户明确同意，并遵守安静时段、每日预算和去重策略。
6. 系统保持“支持性、非诊断、非临床”的产品定位。

### 3.2 技术目标

1. 飞书事件接收与耗时关怀计算解耦。
2. Web 路由和机器人 Tool 共用同一套领域服务。
3. 所有飞书事件可幂等处理、失败重试并保留审计记录。
4. Agent 无权自由指定 `user_id`，用户身份必须由可信运行时注入。
5. 日历访问继续使用每个用户自己的 user_access_token。
6. 第一阶段保持 SQLite 可运行，架构上保留迁移 PostgreSQL/Redis 的空间。

### 3.3 非目标

以下内容不进入第一版：

- 医学诊断、疾病筛查结论或治疗建议；
- 代替心理咨询师、医生或紧急救援服务；
- 自动联系家人、老师、辅导员或其他第三方；
- 在群聊公开个人压力、日程、画像或反馈；
- 让大模型直接访问数据库或飞书 Token；
- 直接把单用户 MCP 的全局 TokenStore 用于所有用户；
- 完全自动、无限制的开放式心理聊天；
- 第一阶段即删除当前 OAuth Callback；
- 第一阶段即引入复杂的跨租户飞书应用体系。

## 4. 默认范围与关键假设

除非后续架构决策记录另行修改，项目采用以下默认值：

| 项目 | 默认决策 |
|---|---|
| 飞书应用类型 | 企业自建应用，启用机器人能力 |
| 租户范围 | 第一版单飞书租户、多用户 |
| 机器人事件方式 | WebSocket 长连接 |
| 支持会话 | 第一版仅机器人单聊 |
| 项目账号 | 保留现有 Mental_project 账号体系 |
| 身份绑定 | 飞书一次性绑定卡片 + Web 登录确认 |
| 普通机器人消息凭证 | tenant_access_token |
| 用户私人日历凭证 | 每用户 user_access_token |
| 日历初始授权 | 第一阶段复用当前 OAuth Callback |
| Device Flow | 后续灰度能力，不是第一阶段前置条件 |
| 关怀生成 | 先确定性规则与模板，后 Agent + Skill |
| 外部 LLM | 默认不允许使用个人历史，遵守 `allow_external_llm` |
| 事件队列 | 第一阶段使用 SQLite 持久化队列 |
| 部署方式 | Web、飞书网关、关怀 Worker 三进程 |

## 5. 用户角色

### 5.1 普通用户

可以：

- 绑定或解除绑定飞书账号；
- 连接或重新授权自己的飞书日历；
- 在飞书私聊中记录当下状态；
- 查看自己的当日关怀摘要；
- 获取符合偏好的关怀建议；
- 对提示进行反馈；
- 开启、暂停或关闭主动关怀；
- 设置关怀语气、支持方式、安静时段和每日上限。

### 5.2 管理员

可以：

- 查看飞书机器人整体运行状态；
- 查看不包含消息正文和 Token 的队列统计；
- 查看失败事件和投递失败原因；
- 停用某个项目用户；
- 查看安全审计记录；
- 配置全局功能开关。

管理员默认不能查看用户私人消息正文、日历事件全文或解密后的 Token。

### 5.3 飞书应用机器人

机器人是应用身份，不是任意用户身份。机器人可以：

- 接收已授权范围内的飞书消息事件；
- 发送文本和交互卡片；
- 引导用户进行账号绑定和日历授权。

机器人不能仅凭 tenant_access_token 读取所有发送者的私人主日历。

## 6. 目标系统架构

```mermaid
flowchart TB
    FU["飞书用户"] --> BG["飞书机器人网关"]
    BG --> INBOX["feishu_inbox_events"]
    INBOX --> CW["关怀 Worker"]
    CW --> ID["身份绑定服务"]
    CW --> CA["Care Agent / 确定性路由器"]
    CA --> SK["mental-health-care Skill"]
    SK --> TOOLS["关怀 Tools"]
    TOOLS --> CS["CareService"]
    CS --> PS["PredictionService"]
    CS --> FS["FeedbackService"]
    CS --> CAL["FeishuCalendarService"]
    CS --> POLICY["CareDeliveryPolicy"]
    POLICY --> OUTBOX["care_deliveries"]
    OUTBOX --> SEND["飞书消息发送客户端"]
    SEND --> FU

    WEB["Vue + Flask Web"] --> CS
    WEB --> ID
    WEB --> CAL
    DB["SQLite / 未来 PostgreSQL"] --- INBOX
    DB --- ID
    DB --- CS
    DB --- OUTBOX
```

### 6.1 进程边界

#### Web 进程

- 继续运行 Vue 和 Flask/Gunicorn；
- 负责项目登录、账号绑定确认、问卷、偏好设置、图表、日历授权和管理员页面；
- 不启动飞书 WebSocket；
- 不运行无限循环 Worker。

#### 飞书机器人网关进程

- 启动飞书 SDK WebSocket Client；
- 接收消息与卡片事件；
- 做最小字段解析和基本校验；
- 将事件写入数据库；
- 在飞书要求的短时间内完成处理；
- 不直接调用大模型或运行全天预测。

#### 关怀 Worker 进程

- 领取待处理事件；
- 查找用户绑定；
- 运行确定性路由或 Care Agent；
- 调用白名单 Tool；
- 执行安全与投递策略；
- 发送回复；
- 处理重试、失败和死信；
- 后续执行主动关怀调度。

## 7. 核心业务流程

### 7.1 首次私聊与账号绑定

```text
用户首次私聊机器人
  -> 网关记录事件
  -> Worker 查询不到 open_id 绑定
  -> 创建一次性绑定 Token
  -> 机器人发送绑定卡片
  -> 用户打开 Web 页面并登录
  -> 用户明确确认绑定
  -> 建立 open_id -> app user_id 映射
  -> 绑定 Token 立即作废
  -> 机器人确认绑定成功
```

### 7.2 轻量状态打卡

```text
用户说“我现在压力大概 7 分，活力 4 分”
  -> 路由为 momentary check-in
  -> 关怀 Tool 校验 0-10 范围和必要字段
  -> 复用 feedback_observations 保存 momentary_state
  -> 返回简短确认和可选支持建议
```

### 7.3 查询今日状态

```text
用户说“今天状态怎么样”
  -> 查询最近一次当日 prediction_run
  -> 若存在，返回精简摘要
  -> 若不存在，询问是否运行当日评估
  -> 若日历未连接，说明结果将只基于现有上下文
```

### 7.4 运行当日评估

```text
用户确认运行
  -> PredictionService 加载用户画像
  -> 尝试读取该用户日历
  -> 读取反馈和跨日上下文
  -> 运行现有模型
  -> 保存 prediction_run
  -> CareService 提取适合机器人展示的摘要
  -> 返回关怀建议
```

### 7.5 日历未连接

```text
Tool 检测到日历未连接
  -> 机器人发送“连接日历”卡片
  -> 用户登录 Web
  -> 复用现有 OAuth Callback 完成授权
  -> /api/feishu/verify 检测主日历
  -> 机器人后续使用该用户自己的 Token
```

### 7.6 主动关怀

```text
预测产生关怀候选
  -> 写入 care_deliveries(candidate)
  -> 检查用户是否启用
  -> 检查安静时段和每日预算
  -> 检查 episode 是否已发送
  -> 检查是否存在单聊会话和有效绑定
  -> 到达发送时间后投递
  -> 保存飞书 message_id
  -> 用户卡片反馈写回 care_review
```

## 8. 功能需求

### 8.1 飞书机器人网关

#### BOT-001 长连接

系统必须使用独立进程建立飞书 WebSocket 长连接，不能由每个 Gunicorn worker 分别建立连接。

#### BOT-002 事件接收

系统必须支持接收：

- 机器人单聊消息；
- 交互卡片点击或表单提交；
- 后续可扩展的授权卡片事件。

#### BOT-003 快速确认

事件处理函数只能完成校验、最小解析和落库，不得同步执行耗时模型或外部 LLM 调用。

#### BOT-004 幂等

相同 `event_id` 或 `message_id` 重复到达时，只允许创建一条业务任务和一次最终回复。

#### BOT-005 消息类型

第一版至少支持：

- 文本；
- 交互卡片按钮；
- 关怀打卡表单。

不支持的消息类型应返回简洁说明，不得抛出未处理异常。

#### BOT-006 单聊限制

第一版个人关怀功能仅允许在单聊中使用。群聊中不得输出个人状态、日历、画像和历史反馈。

### 8.2 身份绑定

#### ID-001 唯一绑定

同一飞书 App 内，一个 `open_id` 只能绑定一个有效项目用户；一个项目用户默认只能绑定一个有效飞书身份。

#### ID-002 明确确认

绑定必须经过用户登录后的明确确认，不能根据飞书姓名、邮箱显示名或学号自动绑定。

#### ID-003 一次性凭证

绑定 Token 必须：

- 使用高熵随机值；
- 数据库只保存哈希；
- 设置短期有效期；
- 成功使用后立即失效；
- 不能重复使用。

#### ID-004 解绑

用户可以从 Web 设置页解除绑定。解绑后机器人不得继续读取其项目数据或发送主动关怀。

#### ID-005 停用用户

项目用户被管理员停用后，机器人必须停止所有查询、回复和主动关怀，仅返回账号不可用提示。

### 8.3 关怀 Tool

#### TOOL-001 工具白名单

第一版只允许调用预定义关怀工具，不允许模型任意访问内部 API、文件系统或数据库。

#### TOOL-002 可信身份注入

所有 Tool 的 `user_id` 必须由绑定服务解析并注入，不能作为模型可编辑参数。

#### TOOL-003 最小返回

Tool 只返回完成当前任务所必需的数据，不向 Agent 返回 access token、refresh token、calendar_id、完整审计记录或完整原始轨迹。

#### TOOL-004 推荐工具集合

第一版需要：

- `care_get_today_context`；
- `care_record_checkin`；
- `care_run_today_assessment`；
- `care_get_support`；
- `care_submit_review`；
- `care_update_preferences`；
- `calendar_connection_status`。

### 8.4 关怀 Agent 与 Skill

#### AGENT-001 分阶段启用

系统必须支持在不开启通用 Agent 的情况下，通过确定性路由完成第一版功能。

#### AGENT-002 Skill 内容

`mental-health-care` Skill 必须明确：

- 意图识别与工具调用顺序；
- 只能使用 Tool 返回的事实；
- 禁止自行估计压力分数；
- 禁止医学诊断；
- 遵守用户语气和支持方式偏好；
- 群聊隐私限制；
- 外部 LLM 使用限制；
- 高风险表达的固定安全流程。

#### AGENT-003 外部 LLM 同意

当 `allow_external_llm=false` 时：

- 不得向外部 LLM 发送个人历史、日历摘要、预测轨迹或反馈；
- 使用确定性模板或经批准的本地处理方式；
- 可以继续使用非 LLM 的关怀 Tool。

#### AGENT-004 输出后检查

Agent 生成的回复在发送前必须经过 `CareSafetyService`，至少检查：

- 是否包含诊断性表述；
- 是否泄露其他用户数据；
- 是否包含不适合群聊的信息；
- 是否违反主动关怀频率；
- 是否出现未经允许的个人历史引用。

### 8.5 日历授权

#### CAL-001 用户身份

私人日历读取必须使用当前绑定用户自己的 user_access_token。

#### CAL-002 第一阶段复用 Callback

第一阶段保留并复用：

- `/api/feishu/get_url`；
- `/callback`；
- `/api/feishu/verify`；
- 现有 refresh token 轮换保护。

#### CAL-003 机器人引导

机器人可以发送日历连接卡片，但不能在消息或卡片内容中包含 Token、calendar_id 或 App Secret。

#### CAL-004 缓存隔离

日历 ID 和日程缓存必须按项目用户隔离。不得使用全局 `primaryCalId`。

#### CAL-005 Device Flow

Device Flow 作为后续可选能力。启用前必须完成：

- 测试飞书应用真实验证；
- 每用户授权 flow 持久化；
- 非阻塞轮询；
- 拒绝、超时和 `slow_down` 处理；
- 多用户并发隔离。

### 8.6 主动关怀

#### CARE-001 明确选择加入

主动关怀必须由用户明确开启，不能仅因用户绑定机器人或连接日历而自动开启。

#### CARE-002 安静时段

普通关怀候选落在安静时段时必须延迟或抑制。默认安静时段沿用画像中的 `23:00-07:00`。

#### CARE-003 每日预算

实际发送次数必须受 `max_daily_messages` 控制。预算应基于已经发送的 `care_deliveries`，不能只依赖单次模型运行中的内存计数。

#### CARE-004 Episode 去重

同一用户、同一日期、同一压力 episode、同一渠道只能发送一次对应层级的关怀。只有明确升级或恢复后重新触发才允许新消息。

#### CARE-005 非临床表述

关怀消息必须保持支持性、建议性，不得把模型输出描述为医学风险、疾病诊断或临床预警。

#### CARE-006 用户控制

每条主动关怀卡片至少提供：

- 有帮助；
- 稍后再提醒；
- 今天不再提醒；
- 关闭主动关怀入口。

#### CARE-007 失败重试

发送失败必须按有限次数和退避策略重试；超过次数后进入失败状态，不能无限重发。

### 8.7 反馈闭环

#### FB-001 打卡反馈

机器人打卡必须复用现有 `momentary_state` 数据格式和 0-10 数值校验。

#### FB-002 关怀反馈

“有帮助”等反馈必须写入 `care_review`，并关联对应 `delivery_id` 和可选 `prediction_run_id`。

#### FB-003 事件完成

机器人必须在事件结束后才允许用户通过卡片确认完成状态，并复用 `event_completion` 反馈。允许值为 `confirmed_completed`、`partial`、`confirmed_incomplete` 和 `rescheduled`。普通课程、会议、考试和恢复类事件默认 `completion_policy=none`，不询问完成；工作时段和交付物事件默认无反馈视为完成，但该默认不得作为确认标签训练模型。

完成反馈不得反写事前预测。系统应保存新的 `forecast_as_of/observed_at`，冻结反馈前的状态点，只从反馈时刻向后更新，并把明确未完成任务带入有界跨日上下文。

当“下周一要交”等截止信息只存在于“今晚完成作业”的日程描述时，系统应从描述中建立隐含义务并与工作时段关联，不要求日历中另有一个截止事件。

#### FB-004 操作者验证

卡片操作必须同时校验：

- 操作者 `open_id` 属于当前绑定用户；
- `delivery_id` 或业务对象属于同一项目用户。

### 8.8 Web 与管理员功能

#### WEB-001 绑定状态

设置页应显示飞书机器人账号绑定状态、绑定时间和解除绑定按钮。

#### WEB-002 关怀偏好

用户可在 Web 修改：

- 是否启用主动关怀；
- 安静时段；
- 每日上限；
- 语气；
- 支持方式；
- 是否允许引用个人历史；
- 是否允许外部 LLM 使用最小必要上下文。

#### WEB-003 管理状态

管理员页面应显示：

- 机器人网关最近心跳；
- 待处理、处理中、失败和死信事件数量；
- 今日发送成功/失败数量；
- 不包含敏感正文的错误摘要。

## 9. 数据模型需求

### 9.1 `feishu_user_bindings`

建议字段：

```text
id
user_id
app_id
tenant_key
open_id
binding_status
bound_at
revoked_at
created_at
updated_at
```

约束：

```text
UNIQUE(app_id, open_id)
UNIQUE(app_id, user_id)
FOREIGN KEY(user_id) -> users(id)
```

### 9.2 `bot_binding_tokens`

```text
token_id
token_hash
app_id
tenant_key
open_id
expires_at
used_at
created_at
```

原始 Token 不得落库。

### 9.3 `feishu_inbox_events`

```text
event_id
message_id
app_id
tenant_key
sender_open_id
chat_id
chat_type
message_type
content_json
status
attempts
available_at
claimed_at
completed_at
last_error
created_at
```

状态：

```text
received
processing
completed
retry_wait
failed
dead_letter
ignored
```

### 9.4 `care_deliveries`

```text
delivery_id
user_id
prediction_run_id
local_date
alert_time
tier
episode_key
channel
status
scheduled_at
sent_at
provider_message_id
failure_reason
created_at
updated_at
```

约束：

```text
UNIQUE(user_id, local_date, episode_key, channel)
```

### 9.5 `feishu_auth_flows`

仅在实现 Device Flow 时增加：

```text
flow_id
user_id
device_code_ciphertext
requested_scopes
status
interval_seconds
next_poll_at
expires_at
created_at
updated_at
```

### 9.6 `care_channel_preferences`

建议将可修改的关怀渠道偏好从不可变画像快照中分离：

```text
user_id
feishu_proactive_enabled
quiet_start
quiet_end
max_daily_messages
tone
preferred_support_json
allow_personal_history_reference
allow_external_llm
updated_at
```

画像快照继续保存当时的初始偏好；当前有效偏好从该表读取。

## 10. 服务接口需求

### 10.1 `PredictionService`

建议内部接口：

```python
run_daily_prediction(
    user_id: int,
    target_date: str,
    force_calendar_refresh: bool = False,
    observations: list | None = None,
) -> PredictionResult
```

要求：

- 从 `/api/simulate` 抽离业务逻辑；
- Web 和机器人共同调用；
- 保持当前预测落库与重放语义；
- 失败时区分日历失败、输入错误和模型错误。

### 10.2 `CareService`

建议接口：

```python
get_today_context(user_id, local_date)
record_checkin(user_id, payload, source)
run_today_assessment(user_id, local_date)
get_support(user_id, context)
submit_review(user_id, delivery_id, payload)
update_preferences(user_id, changes)
```

### 10.3 `FeishuIdentityService`

```python
resolve_binding(app_id, tenant_key, open_id)
create_binding_token(app_id, tenant_key, open_id)
confirm_binding(raw_token, authenticated_user_id)
revoke_binding(authenticated_user_id)
```

### 10.4 `CareDeliveryPolicy`

```python
evaluate_candidate(user_id, candidate, now)
schedule_candidate(user_id, candidate)
claim_due_delivery(worker_id)
mark_sent(delivery_id, provider_message_id)
mark_failed(delivery_id, reason, retry_at)
```

## 11. Web API 需求

建议新增：

```text
GET    /feishu/bind?token=...
POST   /api/feishu/bindings/confirm
GET    /api/feishu/bindings/status
DELETE /api/feishu/bindings/current

GET    /api/care/preferences
PATCH  /api/care/preferences

GET    /api/admin/feishu-bot/status
GET    /api/admin/feishu-bot/failures
POST   /api/admin/feishu-bot/failures/<event_id>/retry
```

要求：

- 绑定确认必须要求浏览器 Session；
- 删除绑定必须要求当前用户或管理员权限；
- 管理员接口不得返回消息全文和解密凭证；
- 所有状态变更写入 `audit_logs`。

## 12. Skill 需求

建议新增：

```text
skills/mental-health-care/SKILL.md
```

Skill 至少包含：

1. 使用范围和非临床定位；
2. 支持的用户意图；
3. 每类意图对应的 Tool 调用顺序；
4. 缺少 onboarding、绑定或日历授权时的处理；
5. 不得猜测模型结果；
6. 不得泄露其他用户或原始凭证；
7. 回复长度、语气与支持方式规则；
8. 群聊限制；
9. 外部 LLM 同意规则；
10. 用户关闭提醒或撤回同意时的动作；
11. 高风险表达的固定安全流程；
12. Tool 失败和降级策略。

Skill 不保存状态，不直接读取数据库，不作为权限控制层。

## 13. 消息与卡片需求

### 13.1 绑定卡片

内容：

- 说明为什么需要绑定；
- 不显示内部 user_id；
- 提供短期绑定按钮；
- 说明绑定后可随时解除。

### 13.2 状态打卡卡片

至少收集：

- 压力 0-10；
- 活力 0-10；
- 当前活动；
- 自上次以来是否发生压力事件；
- 事件是否仍在持续。

### 13.3 关怀反馈卡片

按钮：

- 有帮助；
- 没太大帮助；
- 稍后提醒；
- 今天不再提醒。

### 13.4 日历连接卡片

内容：

- 明确说明读取的是用户自己的飞书日历；
- 说明用途是负荷预测和关怀建议；
- 提供连接按钮；
- 不在卡片中暴露任何凭证或日历标识。

## 14. 安全与隐私需求

### 14.1 数据最小化

- 网关只保存处理必需的事件字段；
- 日历事件进入 Agent 前应转换为负荷摘要，默认不传原始标题和描述；
- 管理员统计不显示消息正文；
- 日志中不得出现 Token、完整 open_id、calendar_id 或敏感消息全文。

### 14.2 Token 安全

- App Secret 只能从环境或密钥服务读取；
- 用户 Token 迁移到数据库后必须加密存储；
- 使用独立 `TOKEN_ENCRYPTION_KEY`，不直接把 App Secret 作为唯一主密钥；
- refresh token 轮换必须原子保存；
- 不得把 Token 返回前端或 Agent。

### 14.3 用户同意

必须分别记录：

- 绑定飞书身份；
- 读取个人日历；
- 接收主动关怀；
- 允许引用个人历史；
- 允许向外部 LLM 发送最小必要上下文。

一项同意不能隐含其他同意。

### 14.4 高风险表达

系统需要独立的安全设计评审。在评审完成前：

- 不自动做临床风险结论；
- 不自动联系第三方；
- 不让普通 Skill 自由生成紧急处置流程；
- 使用经过审核、可配置地区信息的固定支持文本；
- 明确机器人不能替代紧急服务或专业支持。

### 14.5 数据保留

需要配置并记录：

- 飞书原始消息正文保留期限；
- 已处理事件元数据保留期限；
- 失败事件保留期限；
- 关怀投递与反馈保留期限；
- 用户请求删除或解绑时的处理范围。

## 15. 可靠性与并发需求

### 15.1 Worker 领取

多个 Worker 场景下，同一事件只能被一个 Worker 成功领取。SQLite 阶段应使用事务和状态条件更新实现原子 claim。

### 15.2 崩溃恢复

`processing` 状态超过租约时间后，应允许重新进入 `retry_wait`，避免进程崩溃后永久卡住。

### 15.3 有限重试

网络错误和飞书临时错误可以重试；输入错误、解绑用户和权限拒绝不应无限重试。

### 15.4 Refresh Token

继续保持同一用户 Token 的串行刷新。迁移数据库后使用事务、版本号或行级锁替代文件锁。

### 15.5 主动消息去重

关怀投递必须依赖数据库唯一约束，而不是仅靠内存集合。

## 16. 可观测性需求

### 16.1 指标

至少记录：

- 长连接是否在线；
- 最近收到事件时间；
- 每分钟事件数；
- 队列待处理数量；
- 事件处理成功率与延迟；
- 机器人发送成功率；
- 绑定完成率；
- 日历连接成功率；
- 关怀候选数、抑制数和实际发送数；
- 用户关闭主动关怀比例；
- Tool 和 Agent 失败率。

### 16.2 日志

日志应使用：

- `event_id`；
- `delivery_id`；
- `prediction_run_id`；
- 掩码后的用户标识；
- 错误码和阶段。

不得记录解密 Token 或完整个人消息。

### 16.3 审计

以下动作写入审计日志：

- 绑定和解绑；
- 主动关怀开关变化；
- 外部 LLM 同意变化；
- 日历重新授权；
- 管理员重试失败事件；
- 管理员停用用户。

## 17. 配置需求

建议新增环境变量：

```text
FEISHU_BOT_ENABLED=false
FEISHU_BOT_TRANSPORT=websocket
FEISHU_APP_ID=
FEISHU_APP_SECRET=
FEISHU_BIND_BASE_URL=
FEISHU_BOT_PRIVATE_CHAT_ONLY=true

CARE_WORKER_ENABLED=true
CARE_WORKER_POLL_SECONDS=1
CARE_WORKER_MAX_ATTEMPTS=5
CARE_EVENT_LEASE_SECONDS=120
CARE_EVENT_RETENTION_DAYS=30

CARE_AGENT_ENABLED=false
CARE_AGENT_PROVIDER=
CARE_AGENT_MODEL=
CARE_AGENT_TIMEOUT_SECONDS=15

TOKEN_ENCRYPTION_KEY=
```

生产环境启动时必须校验：

- 机器人启用时 App ID/Secret 非空；
- `FEISHU_BIND_BASE_URL` 是 HTTPS；
- Agent 启用时 Provider、Model 和凭证齐全；
- Token 数据库加密启用后密钥非空且长度符合要求。

## 18. 部署需求

`compose.yaml` 目标形态：

```text
app
  command: gunicorn ...

feishu_bot
  command: python -m entry.feishu_bot

care_worker
  command: python -m entry.care_worker
```

三个服务使用同一镜像和同一配置来源，并共享 `/app/data`。

要求：

- Web 健康检查保持不变；
- 机器人网关提供数据库心跳；
- Worker 提供数据库心跳；
- 机器人或 Worker 暂时不可用时，Web 核心功能仍可使用；
- 不得在 Flask import 或 Gunicorn worker 初始化阶段启动长连接。

## 19. 文件改造清单

### 19.1 修改现有文件

#### `auth/database.py`

- 增加新表迁移；
- 增加绑定、事件 claim、投递和偏好方法；
- 增加管理员统计；
- 保持所有用户查询都带 `user_id` 条件。

#### `entry/app.py`

- 抽离 `/api/simulate`；
- 增加绑定确认和绑定状态接口；
- 增加关怀偏好接口；
- 增加机器人管理员状态接口；
- 保留当前日历授权接口。

#### `services/onboarding.py`

- 在问卷或后续设置中明确飞书主动关怀同意；
- 将当前有效偏好迁移到可修改表；
- 保持历史画像快照不变。

#### `utils/get_token.py`

- 中期迁移到数据库加密存储；
- 保留 v2 Token 和 refresh token 轮换；
- 提供面向 `user_id` 的 Token repository 接口。

#### `compose.yaml`

- 增加机器人网关和 Worker 服务。

#### `requirements.txt`

- 增加并锁定飞书 Python SDK；
- 增加经过评审的加密依赖。

#### `.env.example`

- 增加机器人、Worker、Agent 和加密配置说明。

### 19.2 新增文件

```text
integrations/
  feishu/
    __init__.py
    client.py
    events.py
    cards.py
    identity.py

services/
  prediction_service.py
  care_service.py
  care_delivery.py
  care_agent.py
  care_safety.py
  feishu_message_processor.py

entry/
  feishu_bot.py
  care_worker.py

skills/
  mental-health-care/
    SKILL.md

tests/
  test_feishu_bot_events.py
  test_feishu_bindings.py
  test_care_tools.py
  test_care_delivery.py
  test_care_agent.py
  test_feishu_multiuser_isolation.py
```

## 20. 分阶段实施路径

### 阶段 0：领域服务抽离

工作：

- 从 `/api/simulate` 抽离 `PredictionService`；
- 建立 `CareService`；
- 保持现有 Web API 响应兼容；
- 为服务接口增加单元测试。

退出标准：

- 当前前端行为不变；
- 当前全部测试继续通过；
- Web 路由和直接服务调用结果一致。

### 阶段 1：机器人连通性

工作：

- 创建飞书自建应用机器人；
- 配置权限和长连接；
- 新增 `feishu_bot` 进程；
- 创建事件表和幂等处理；
- Worker 返回固定健康回复。

退出标准：

- 单聊消息可以收到并回复；
- 重复事件只回复一次；
- 网关重启后不丢已落库事件；
- Web 服务不受影响。

### 阶段 2：账号绑定

工作：

- 新增绑定表和一次性 Token；
- 新增 Web 绑定确认页面；
- 实现绑定、解绑和停用检查。

退出标准：

- 两个飞书用户分别绑定两个项目用户；
- 不存在跨用户数据读取；
- 一次性 Token 不能重放；
- 解绑后立即停止数据访问。

### 阶段 3：确定性关怀工具

工作：

- 实现关怀 Tool；
- 支持状态打卡、今日状态、运行评估和关怀反馈；
- 使用现有 AlertMonitor 模板；
- Agent 默认关闭。

退出标准：

- 用户可以完成完整的打卡—评估—建议—反馈闭环；
- 未允许外部 LLM 时没有个人数据外发；
- Tool 无法切换到其他 user_id。

### 阶段 4：日历接入

工作：

- 机器人发送日历连接卡片；
- 复用当前 Callback；
- 连接状态 Tool；
- 验证按用户读取主日历。

退出标准：

- 用户 A/B 分别读取自己的日历；
- Token 过期时正确串行刷新；
- 日历失败时关怀功能可降级运行。

### 阶段 5：Agent + Skill

工作：

- 创建 `mental-health-care` Skill；
- 建立 Care Agent；
- 配置工具白名单和可信上下文；
- 增加输出安全检查；
- 遵守外部 LLM 同意。

退出标准：

- Agent 只能访问白名单 Tool；
- 不会猜测不存在的用户状态；
- 不输出诊断性结论；
- 禁止群聊隐私输出；
- Agent 失败时回退确定性回复。

### 阶段 6：主动关怀

工作：

- 增加 `care_deliveries`；
- 生成并调度关怀候选；
- 实现安静时段、每日预算、episode 去重和有限重试；
- 增加反馈卡片。

退出标准：

- 默认未同意用户不收到主动消息；
- 同一 episode 不重复发送；
- 安静时段不发送普通关怀；
- 用户关闭后立即停止；
- 每条发送都有可审计记录。

### 阶段 7：Device Flow 与扩容

工作：

- 增加 Device Flow 灰度开关；
- Token 数据库加密；
- 授权 flow 持久化；
- 评估 PostgreSQL/Redis；
- 多 Worker 并发和灾难恢复测试。

退出标准：

- 不依赖长 HTTP 请求；
- 多用户同时授权不覆盖；
- 服务重启后授权状态可恢复；
- Callback 仍可作为回退，直到正式下线决策通过。

## 21. 测试矩阵

### 21.1 单元测试

- 飞书事件解析；
- 重复事件去重；
- 绑定 Token 哈希、过期和一次性使用；
- open_id 到 user_id 解析；
- Tool 身份注入；
- 关怀偏好解析；
- 安静时段；
- 每日消息预算；
- episode 去重；
- 投递状态转换；
- Agent 输出安全检查；
- 日历连接状态；
- Token 刷新竞争。

### 21.2 集成测试

- 飞书 SDK 使用 Fake Client；
- 事件入库—Worker 领取—回复完整链路；
- 打卡保存到 `feedback_observations`；
- 机器人触发 PredictionService；
- 关怀反馈关联 delivery；
- Web 绑定确认；
- 解绑和停用即时生效。

### 21.3 多用户隔离测试

- 用户 A 不能读取用户 B 的画像；
- 用户 A 不能读取用户 B 的预测；
- 用户 A 不能使用用户 B 的日历 Token；
- 用户 A 不能操作用户 B 的卡片；
- Agent 无法通过参数注入其他 user_id；
- 全局缓存不得混用主日历 ID。

### 21.4 恢复测试

- 网关断线重连；
- Worker 处理中崩溃；
- SQLite 临时锁；
- 飞书发送超时；
- 外部 LLM 超时；
- 日历 API 超时；
- refresh token 已轮换；
- 进程重启后继续处理未完成事件。

### 21.5 安全测试

- 绑定 Token 重放；
- 伪造 card action；
- 群聊隐私请求；
- 未同意主动关怀；
- 未同意外部 LLM；
- 日志敏感信息扫描；
- Token 不出现在 API 响应和 Agent 上下文；
- 管理员接口不返回消息全文。

## 22. 第一版最小可用范围

第一版必须形成以下闭环：

```text
飞书单聊
  -> 账号绑定
  -> 记录此刻
  -> 查看今天状态
  -> 运行现有预测
  -> 返回确定性关怀提示
  -> 用户反馈是否有帮助
```

第一版暂不要求：

- 主动定时推送；
- Device Flow；
- 通用 Agent；
- 开放式心理聊天；
- 群聊个人关怀；
- 外部 LLM 读取个人历史；
- 自动危机处置。

## 23. 第一版验收标准

### 功能验收

- [ ] 飞书单聊消息可以稳定接收和回复；
- [ ] 未绑定用户只能收到绑定引导；
- [ ] 用户可以完成安全绑定和解绑；
- [ ] 用户可以提交符合现有 EMA 结构的状态打卡；
- [ ] 用户可以查询当日预测摘要；
- [ ] 用户可以触发当日预测；
- [ ] 用户可以收到确定性关怀建议；
- [ ] 用户可以提交关怀反馈；
- [ ] Web 原功能保持兼容。

### 隔离验收

- [ ] 两个用户的绑定、预测、反馈和日历完全隔离；
- [ ] Tool 参数中不存在模型可控制的 user_id；
- [ ] 群聊不输出个人数据；
- [ ] 停用或解绑后立即停止访问。

### 可靠性验收

- [ ] 重复事件只回复一次；
- [ ] Worker 重启后未完成事件可以恢复；
- [ ] 飞书发送失败有限重试；
- [ ] 日历失败时仍能返回降级结果；
- [ ] Web、网关和 Worker 可以独立重启。

### 安全验收

- [ ] Token 不进入日志、前端响应和 Agent 上下文；
- [ ] 绑定 Token 一次性且短期有效；
- [ ] 外部 LLM 默认不接收个人历史；
- [ ] 回复不包含医学诊断；
- [ ] 管理员默认看不到消息正文。

## 24. 待决策事项

以下事项需要在相应阶段开始前形成明确决定：

| 编号 | 决策问题 | 推荐默认值 | 最晚决策阶段 |
|---|---|---|---|
| ADR-001 | 是否长期只支持单飞书租户 | 第一版是 | 阶段 1 |
| ADR-002 | 是否允许飞书身份自动创建项目账号 | 否，先绑定现有账号 | 阶段 2 |
| ADR-003 | SQLite 队列何时迁移 | 达到明确并发阈值后迁移 | 阶段 6 前 |
| ADR-004 | 外部关怀 LLM Provider | 未确定，默认关闭 | 阶段 5 |
| ADR-005 | 是否保留完整消息正文 | 默认最短保留或不保留 | 阶段 1 |
| ADR-006 | 主动关怀默认值 | 默认关闭 | 阶段 6 |
| ADR-007 | Device Flow 是否替换 Callback | 灰度验证后决定 | 阶段 7 |
| ADR-008 | 高风险表达产品策略 | 需独立安全评审 | 阶段 5 前 |
| ADR-009 | 用户删除请求的数据范围 | 需隐私策略确认 | 阶段 2 |
| ADR-010 | Token 加密与密钥管理方案 | 独立加密密钥，后续 KMS | 阶段 4 前 |

## 25. 完成定义

某个阶段只有在以下条件全部满足后才算完成：

1. 对应需求已实现；
2. 数据库迁移可重复执行；
3. 新增单元测试与集成测试通过；
4. 现有测试无回归；
5. 前端生产构建通过；
6. 环境变量和部署说明已更新；
7. 日志无敏感凭证；
8. 多用户隔离测试通过；
9. 失败和降级路径已验证；
10. 相关 ADR 已记录。

## 26. 推荐执行顺序总结

```text
先抽离共享业务服务
  -> 接通飞书机器人和持久化队列
  -> 建立可信账号绑定
  -> 实现确定性关怀 Tools
  -> 复用现有日历 OAuth
  -> 加入 Agent + Skill
  -> 加入主动关怀投递
  -> 最后评估 Device Flow 和基础设施扩容
```

该顺序保证每一阶段都能形成可测试、可回退的增量，不会在一开始同时引入机器人、MCP、Agent、Device Flow、主动推送和多进程调度等全部复杂性。
