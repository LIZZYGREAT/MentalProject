# 飞书关怀机器人部署与验收

## 第一版范围

第一版使用企业自建应用的 WebSocket 长连接接收机器人单聊与卡片操作，保留现有 Web OAuth Callback 读取每位用户自己的主日历。主动定时推送、Device Flow 和通用关怀 Agent 尚未启用。

## 飞书开放平台配置

1. 在同一个企业自建应用中启用机器人能力。
2. 在权限管理中开通接收机器人消息和以机器人身份发送消息所需权限，并发布应用版本。
3. 在事件订阅中选择“使用长连接接收事件”，订阅 `im.message.receive_v1`。
4. 配置并发布 `card.action.trigger` 卡片回调，以支持打卡与反馈按钮。
5. 日历 User OAuth 继续发布 `offline_access`、用户身份读取和日历只读权限；重定向地址与 `FEISHU_REDIRECT_URI` 精确一致。

长连接只接收消息/卡片事件，不会替代私人日历的 `user_access_token`。

## 环境配置

从 `.env.example` 复制配置，至少填写：

```text
FEISHU_APP_ID
FEISHU_APP_SECRET
FEISHU_REDIRECT_URI
FEISHU_FRONTEND_ORIGIN
FEISHU_BIND_BASE_URL
FEISHU_BOT_ENABLED=true
```

生产环境的 `FEISHU_REDIRECT_URI`、`FEISHU_FRONTEND_ORIGIN` 和 `FEISHU_BIND_BASE_URL` 必须使用受信任的 HTTPS 域名。不要配置全局用户 `open_id`、`calendar_id` 或共享用户 Token。

## 进程启动

容器部署：

```text
docker compose up --build
```

本地分别运行：

```text
python -m entry.feishu_bot
python -m entry.care_worker
python wsgi.py
```

Web、机器人网关和 Worker 共用 `APP_DATABASE_PATH`；不要在 Gunicorn worker 内启动长连接或队列循环。

## 验收路径

1. 未绑定用户私聊机器人，收到一次性绑定卡片。
2. 登录 Web 并明确确认绑定；重复使用同一链接应失败。
3. 在飞书发送“我现在压力大概 7 分，活力 4 分”，Web 反馈列表出现 `momentary_state`。
4. 发送“今天状态怎么样”和“运行今日评估”；未连接日历时应明确返回降级说明。
5. 发送“给我一点支持”，点击“有帮助”；反馈应关联同一用户的 `delivery_id`。
6. 在群聊请求个人状态，只返回隐私提示。
7. 在 Web 设置解除绑定后，再次私聊只能收到绑定引导。
8. 管理员通过 `/api/admin/feishu-bot/status` 查看脱敏队列和心跳；失败列表不得包含消息正文、Token 或完整飞书身份。

## 自动化验证

```text
python -m pytest -q
npm.cmd run build
docker compose config --quiet
```
